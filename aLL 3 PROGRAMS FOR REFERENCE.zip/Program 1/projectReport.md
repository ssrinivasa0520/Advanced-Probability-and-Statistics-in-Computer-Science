Program  I - Random Bridge Hand Report
CS355/555
Spring 2023
Hughston Davis & Shreyas Srinivasa

Files:
randomBridge.py, 
CS_Decleration_of_Independent_Completion.pdf,
CS_Decleration_of_Independent_Completion.docx, 
projectReport.md, 
Program1.pdf

Parent File: CS355_Hughhugh_Shreyas_Program1.zip

### Concepts

#### Deterministic Shuffling -
    Half deck

#### Non-Deterministic Shuffling -
    Half deck A half deck B. 1/2 A 1/2 B. Choose card at random from larger pile. 

#### Correlation Coeffiecient - 

#### Arrays -
    We used Arrays to store which card was at which slot and used 0-51 as card IDs for the 52 cards in a deck.


### Report

#### Summary - 
    Take a random card from 52 cards and put it in a new array that switches betweeen filling in the first index to the halfway point and the halfway point and the last card every other shuffle.


#### Questions -

#### Code Explanation - 
       
