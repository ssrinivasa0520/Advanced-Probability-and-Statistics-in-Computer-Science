Program  I - Random Bridge Hand Report
CS355/555
Spring 2023
Hughston Davis & Shreyas Srinivasa

We declare that we have completed this assignment in accordance with the UAB Academic Integrity Code and the UAB CS Honor Code. We have read the UAB Academic Integrity Code and understand that any breach of the Code may result in severe penalties.
We also declare that the following percentage distribution faithfully represents individual group members’ contributions to the completion of the assignment
Names| Hughston Davis, Shreyas Srinivasa	
Overall Contribution (%) 50% on all work	      
Major work items completed by me | All items were worked on in-person or online
Signature / initials| HD/SS
Date: 04/03/2023
	
		
		

Files:
main.py, 
CS_Decleration_of_Independent_Completion.pdf,
CS_Decleration_of_Independent_Completion.docx, 
projectReport.md, 
52_shuffle.png,
52_top.png,
104_shuffle.png,
104_top.png

Parent File: CS355_Hughhugh_Shreyas_Program2.zip

### Concepts

#### Deterministic Shuffling vs. Non-Deterministic Shuffling
    The concepts for this program deal with patterns of cards being shuffled by halfing a deck and inserting a card alternating between stacks randomly choosing which stack to pick with preference towards the larger stack based on the ratio.
 

#### Correlation Coeffiecient
    This Coeffiecient shows us the relation of the newly shuffled deck to the original deck before any shuffling.

#### Arrays -
    We used Arrays to store which card was at which slot and used 0-51 as card IDs for the 52 cards in a deck. We also used Arrays to store each halves.


### Report

#### Summary - 
    We made functions to handle each type of shuffling (52 card and 104 card with shuffling from the top of a random stack or a random card alternating between stacks)
    


#### Questions -
    First Run - 1. At roughly 4 and 12
                2. No, After 15 runs the deck doesn't show any signs of returning to 1
                3. No
                4. No

    Second Run - 1. At several points the r value hits 0.    
                 2. No 
                 3. No
                 4. No
    
    Third Run - 1. At several points the r value hits 0
                2. No 
                3. No
                4. No

    Fourth run - 1. At several points the r value hits 0
                2. No
                3. No
                4. No

#### Code Explanation - 
We used functions, loops, and arrays to plot our results to screen
       
