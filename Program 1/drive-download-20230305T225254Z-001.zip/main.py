import randomShuffle
import matplotlib.pyplot as plt
import numpy
originalDeck = []
rValues = []
def main():
    global count
    n = 52
    shuffles = 15 
    for x in range(n):
        originalDeck.append(x)
    newDeck = randomShuffle.shuffleAB(originalDeck)
    rValues.append(randomShuffle.ccRatio(originalDeck,newDeck))
    for x in range(shuffles-1):
        
        rValues.append(randomShuffle.ccRatio(originalDeck,newDeck))
        orignalDeck = newDeck
        newDeck = randomShuffle.shuffleAB(originalDeck)
      
        
        
    print(rValues)
    fig, AB = plt.subplots()
    AB.plot(rValues)
    plt.show()
    
main()
