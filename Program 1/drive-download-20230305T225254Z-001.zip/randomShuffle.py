import math
import matplotlib.pyplot as plt
import numpy as np



def shuffleAB(originalDeck):
    count = 0
    newDeck = []
    stackA = []
    stackB = []
    for i in range(len(originalDeck)):
        
        if i % 2 == 1:        
            stackA.append(originalDeck[i])
        elif i % 2 == 0:
            stackB.append(originalDeck[i])
            
            
    
    while len(stackA) > 0 or len(stackB) > 0:
        if count % 2 == 1:
            count = count + 1
            card = stackA[0]
            newDeck.append(card)
            del stackA[0]
            
        elif count % 2 == 0:
            count = count + 1
            card = stackB[0]
            newDeck.append(card)
            del stackB[0]
        elif len(stackB) > 0:
            card = stackB[0]
            newDeck.append(card)
            del stackB[0]
        elif len(stackA) > 0:
            card = stackA[0]
            newDeck.append(card)
            del stackA[0]
        
    return newDeck
def shuffleBA(numOfCards): 
    count = 0
    newDeck = []
    stackA = []
    stackB = []
    for i in range(numOfCards):
        
        if i % 2 == 1:
            stackA.append(i)
        elif i % 2 == 0:
            stackB.append(i)
    
    while len(stackA) > 0 or len(stackB) > 0:
        count = count + 1
        if len(stackB) == 0:
            
            card = stackA[0]            
            newDeck.append(card)
            del stackA[0]
        
        elif len(stackA) == 0:
            card = stackB[0]            
            newDeck.append(card)
            del stackA[0]
            
        elif count % 2 == 1:
            card = stackB[0]
            newDeck.append(card)
            del stackB[0]
            
        elif count % 2 == 0:
            card = stackA[0]
            newDeck.append(card)
            del stackB[0]

def sumNum(numberOfCards):
    sum = 0
    for x in range(numberOfCards):
        sum = sum + x
    return sum

def sumNumSQ(numberOfCards):
    sum = 0
    for i in range(numberOfCards):
        sum = sum + ((i)^2)
      
    return sum
def ccRatio(originalDeck, newDeck):
    ratio = 0
    for j in range(1,len(originalDeck)-1):
        ratio = ratio + originalDeck[j] * newDeck[j]
    cc = (len(originalDeck) * ratio) - (sumNum(len(originalDeck))^2)/((len(originalDeck)* sumNumSQ(len(originalDeck))) - sumNum(len(originalDeck))^2)
    return cc
    